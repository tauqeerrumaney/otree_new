# for compat with apps written in older versions
# unfortunately this is still hardcoded in some widespread apps' _builtin/__init__.py
from otree.bots import Bot  # noqa
