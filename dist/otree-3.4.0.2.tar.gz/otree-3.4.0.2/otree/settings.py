def augment_settings(*args, **kwargs):
    '''don't need this, now that we do it in otree-core'''
    pass
