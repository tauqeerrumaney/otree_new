# Legacy: It used to be {% load otree_tags %}
from .otree import register  # noqa
